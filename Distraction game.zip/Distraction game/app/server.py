from flask import Flask, request, json, jsonify, render_template
from flask_cors import CORS, cross_origin

app = Flask(__name__)
cors = CORS(app, resources={r"/save": {"origins": "*"}})
app.config['JSON_AS_ASCII']=False


@app.route('/save', methods=['POST'])
@cross_origin(origin='localhost', allow_headers=['Content-Type'])
def api_save():
    file_obj = open('results.json', 'a')
    file_obj.write(json.dumps(request.json) + "\n")

    return jsonify(success=True)


@app.route('/', methods=['GET'])
def root():
    return render_template('game.html')


@app.errorhandler(404)
def page_not_found(e):
    return '<h1>Page Not Found</h1>\n', 404


if __name__ == '__main__':
    app.run(debug=True, host='localhost', port=3000)
